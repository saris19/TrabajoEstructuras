package com.example.demo.service.DTO;

import lombok.Data;
import java.util.List;

@Data
public class DetectionsWrapper {
    private List<DetectionJson> detections;
}



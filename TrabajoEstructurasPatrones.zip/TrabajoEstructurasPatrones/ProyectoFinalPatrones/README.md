# ProyectoFinalPatrones
python
pip install ultralytics

mvn spring-boot:run
http://localhost:8080/api/detections/analysis/summary ver promedio y maximo visible
